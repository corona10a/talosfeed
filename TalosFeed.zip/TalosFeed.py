# importing the requests library
import requests
 
# Talos Request Feed
url = "https://talosintelligence.com/documents/ip-blacklist"

# Sending get request and saving the response as response object
response = requests.get(url)

#Save in file Path and write data (IOCs)
open('C:\Scripts\Talos\TalosFeed_IPReputation.txt', 'wb').write(response.content)

# printing the output
#print(response.content)
print(response.text)
#print(response.status_code) 